#!/bin/bash

echo "🧱 Starting build and install process for Pong Masters..."

echo "🔧 Checking for build tools..."
sudo apt update
sudo apt install -y build-essential

echo "⚙️ Building the game..."
make clean
make

if [ ! -f PongMasters ]; then
    echo "❌ Build failed: PongMasters binary not found."
    exit 1
fi

echo "📁 Installing to /opt/my-game..."
sudo mkdir -p /opt/my-game
sudo cp PongMasters /opt/my-game/
sudo chmod +x /opt/my-game/PongMasters

echo "🖥️ Creating desktop shortcut..."
cat <<EOF | sudo tee /usr/share/applications/pongmasters.desktop > /dev/null
[Desktop Entry]
Name=Pong Masters
Exec=/opt/my-game/PongMasters
Icon=applications-games
Type=Application
Categories=Game;
Terminal=false
EOF

echo "✅ Pong Masters installed successfully!"
echo "➡️ Launch it from the application menu or by typing: /opt/my-game/PongMasters"
